import React from 'react';
import './Header.css'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInstagram } from '@fortawesome/free-brands-svg-icons';
import { faFacebookF } from '@fortawesome/free-brands-svg-icons';
import { faPhone } from '@fortawesome/free-solid-svg-icons';






function Header(){

    return(
        <header>
           


            <div className="first-row">
            <div className="phone-number" > <FontAwesomeIcon icon={faPhone} shake style={{color: "#B197FC",}} />  6973829102
            <div className="social-icons">
            <a href="https://www.instagram.com/dogwalker.fwteinh/" className="social-icon"><FontAwesomeIcon icon={faInstagram} size="xl" style={{ color: "#aa5dac" }} /></a>
            <a href="https://www.facebook.com/profile.php?id=61561162122957" className="social-icon"><FontAwesomeIcon icon={faFacebookF} size="xl" style={{ color: "#aa5dac" }} /></a>
            </div></div>
            <div><h1>Dog Walker Φωτεινή</h1></div>

            <button className="reservation-button"><a href="">Κάνε Κράτηση</a></button>
            </div>

            <hr></hr>
            <nav className="navbar">
                <ul>
                    <li><a href="">Φόρμα Επικοινωνίας</a></li>
                    <li><a href="">Σύνδεση</a></li>
                    <li><a href="">Εγγραφή</a></li>


                </ul>


            </nav>
        </header>

    );
}

export default Header